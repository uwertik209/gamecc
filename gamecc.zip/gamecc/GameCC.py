import abc

class BaseCommand(abc.ABC):
    def __init__(self, value=None):
        self.value = value[0] if value and isinstance(value, list) else value

    @abc.abstractmethod
    def execute(self):
        pass

# --- Команды CS:GO ---
class NetGraph(BaseCommand):
    def execute(self): return f"NetGraph set to {self.value} (CS:GO only)"

# --- Команды CS2 ---
class CqNetgraph(BaseCommand):
    def execute(self): return f"CQ Netgraph toggled (CS2 only)"

# --- Общие команды ---
class SvCheats(BaseCommand):
    def execute(self): return f"sv_cheats {self.value}"

class Noclip(BaseCommand):
    def execute(self): return "Noclip mode changed"

# Реестры команд
CSGO_ONLY = {"net_graph": NetGraph}
CS2_ONLY = {"cq_netgraph": CqNetgraph}
COMMON = {
    "sv_cheats": SvCheats,
    "noclip": Noclip,
    "sv_gravity": type("SvGravity", (BaseCommand,), {"execute": lambda s: f"Gravity: {s.value}"}),
    "bot_kick": type("BotKick", (BaseCommand,), {"execute": lambda s: "Bots kicked"})
}

def get_commands(game_choice):
    """Возвращает набор команд в зависимости от игры"""
    cmds = COMMON.copy()
    if game_choice.lower() == "csgo":
        cmds.update(CSGO_ONLY)
    elif game_choice.lower() == "cs2":
        cmds.update(CS2_ONLY)
    return cmds
