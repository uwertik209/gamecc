from setuptools import setup, find_packages

setup(
    name="GameCC",
    version="1.0.0",
    packages=find_packages(),
    py_modules=["gamecc.GameCC", "gamecc.main"],
    entry_points={
        'console_scripts': [
            # Это создаст команду 'gcc' в Windows, которую можно вводить в Win+R
            'gcc = gamecc.main:main_entry',
        ],
    },
    author="YourName",
    description="Game Cheat Console for CS:GO and CS2",
)
