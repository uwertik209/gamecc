import GameCC
import shutil
import subprocess

class PowerConsole:
    def __init__(self):
        self.commands = {}
        self.setup_game()

    def setup_game(self):
        print("--- GameCheatConsole (GameCC) ---")
        choice = input("Выберете игру (CSGO/CS2): ").strip().upper()
        
        if choice not in ["CSGO", "CS2"]:
            print("Неверный выбор. Загружены общие команды.")
            choice = "COMMON"
            
        self.commands = GameCC.get_commands(choice)
        print(f"Библиотека GameCC инициализирована для: {choice}\n")

    def launch_system(self, cmd, args):
        path = shutil.which(cmd)
        if path:
            try:
                # Запуск без ожидания завершения
                subprocess.Popen([path] + args, shell=True)
                return True
            except:
                return False
        return False

    def start(self):
        while True:
            try:
                raw = input("GameCC > ").strip().split()
                if not raw: continue
                
                cmd_name = raw[0].lower()
                args = raw[1:]

                if cmd_name in ["exit", "quit"]: break

                # 1. Сначала ищем в классах GameCC
                if cmd_name in self.commands:
                    cmd_class = self.commands[cmd_name]
                    instance = cmd_class(args)
                    print(f"[GameCC] {instance.execute()}")
                
                # 2. Потом ищем приложение в системе
                elif self.launch_system(cmd_name, args):
                    print(f"[System] Приложение '{cmd_name}' запущено.")
                
                else:
                    print(f"Ошибка: Команда или программа '{cmd_name}' не найдена.")
            except KeyboardInterrupt:
                break

if __name__ == "__main__":
    app = PowerConsole()
    app.start()
# В конце файла main.py добавь:
def main_entry():
    app = PowerConsole()
    app.start()

if __name__ == "__main__":
    main_entry()
